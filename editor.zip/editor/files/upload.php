<?php
/**
 * Created by PhpStorm.
 * User: EL
 * Date: 16/9/18
 * Time: 下午1:29
 */
echo "http://i1.pro.fd.zol-img.com.cn/t_s640x2000_w1/g5/M00/0D/0B/ChMkJleVzVuIdOQFAAlYVTXIMl4AAT0EwEtaXYACVht037.jpg";