CREATE PROCEDURE salvage_selct(IN car_modeid INT)
  BEGIN   
			 /*车辆保值表计算方法
				car_modeid -- 车辆id号	
				*/
        SELECT * from newcar.mode_salvage_detail t WHERE t.salvageid = (SELECT id from newcar.mode_salvage t where t.modeid=car_modeid);   
END;
