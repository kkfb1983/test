CREATE PROCEDURE TEMP(OUT b INT)
  BEGIN
  set @a=(SELECT COUNT(*)  FROM person_credit WHERE tel='14598700110');
       /**set @a=1;**/
if (@a>0) THEN
    select @b:=uid  from person_credit WHERE fullname='图图十';
else
    select @b:=SUBSTRING(content,5,4)  FROM sms_message WHERE messageid=(SELECT MAX(messageid) FROM sms_message WHERE mobile='14598700010');
end if;

END;
