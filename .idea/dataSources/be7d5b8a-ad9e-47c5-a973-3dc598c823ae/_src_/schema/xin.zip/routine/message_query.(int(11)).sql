CREATE PROCEDURE message_query(IN mobile INT)
  BEGIN   
			 /*短信验证码查询，usrid查询	
				*/
        SELECT * from xin.sms_message t where  t.mobile=mobile;
				#SELECT * from xin.webank_apply_data t  where t.bank_mobile = mobile; 
        select   t.userid,t.bank_id from xin.webank_apply_data t where t.bank_mobile=mobile;

END;
