CREATE PROCEDURE LENDING_QUERY(IN id INT)
  BEGIN   
			 /*放款后查询，applyid查询	
				*/
               select *,amount,loan_type from xin.car_half_loan_record where applyid=id;
				

END;
