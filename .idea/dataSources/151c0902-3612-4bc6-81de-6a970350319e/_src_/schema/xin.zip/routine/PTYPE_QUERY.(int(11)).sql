CREATE PROCEDURE PTYPE_QUERY(IN id INT)
  BEGIN   
			 /*请款后，applyid查询	请款，请款要先执行http://erp_newcar_xinnet.erp.ceshi.youxinjinrong.com/testbank/bankLoanApply?applyid=
在执行该
				*/
          SELECT * FROM xin_finance.`bank_interface_log`  t  where t.interface_name in ('UXTransactionInfo','B2ELoanApply') and t.applyid =id;
				

END;
